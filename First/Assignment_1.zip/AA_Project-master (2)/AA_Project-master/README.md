# AA Project

This is the projects folder for the class ["Aprendizagem Automatica"](http://aa.ssdi.di.fct.unl.pt/) at NOVA FCT Lisbon.

Partecipants:
- Emanuele Vivoli
- Simone Rossi
